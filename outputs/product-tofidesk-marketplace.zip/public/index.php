<?php
declare(strict_types=1);
// Safe deployment marker: it contains no secrets and lets a hosting check
// prove which package is actually serving the request.
$tofideskRelease = (string)(getenv('APP_VERSION') ?: '2026.11.05-platform');
if (!headers_sent()) {
    header('X-TofiDesk-Product: cms');
    header('X-TofiDesk-Release: ' . preg_replace('/[^A-Za-z0-9._-]/', '-', $tofideskRelease));
}
function tofidesk_startup_failure(string $message): never {
    if (!headers_sent()) {
        http_response_code(503);
        header('Content-Type: text/html; charset=utf-8');
        header('Cache-Control: no-store');
    }
    $detail = htmlspecialchars($message, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TofiDesk kurulum tanılama</title><style>body{font:16px/1.6 system-ui;background:#092b3d;color:#153346;margin:0;padding:28px}.card{max-width:780px;margin:8vh auto;background:#f7faf8;border-radius:18px;padding:34px}h1{color:#08283a}code{display:block;background:#edf3f0;padding:14px;border-radius:8px;white-space:pre-wrap;overflow-wrap:anywhere;color:#7a241b}</style><main class="card"><strong>TOFIDESK</strong><h1>Kurulum tanılaması gerekli</h1><p>Uygulama başlangıcında bir hata oluştu. Plesk hata günlüğündeki kayıtla karşılaştırın.</p><code>'.$detail.'</code><p>Kontrol: <b>storage</b> yazma izni, SQLite/PDO SQLite uzantıları ve httpdocs dosya bütünlüğü.</p></main>';
    exit;
}
set_exception_handler(static function (Throwable $exception): never {
    tofidesk_startup_failure(get_class($exception).': '.$exception->getMessage());
});
register_shutdown_function(static function (): void {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_PARSE], true)) {
        tofidesk_startup_failure($error['message']);
    }
});
function preflight_requirements_page(): void {
    $required = ['pdo_sqlite' => 'PDO SQLite', 'sqlite3' => 'SQLite3', 'curl' => 'cURL', 'openssl' => 'OpenSSL', 'mbstring' => 'mbstring', 'fileinfo' => 'fileinfo', 'gd' => 'GD/WebP'];
    $missing = [];
    if (version_compare(PHP_VERSION, '8.2.0', '<')) $missing[] = 'PHP 8.2+ (mevcut: '.PHP_VERSION.')';
    foreach ($required as $extension => $label) if (!extension_loaded($extension)) $missing[] = $label;
    if (!$missing) {
        $storage = dirname(__DIR__) . '/storage';
        if (!is_dir($storage) && !@mkdir($storage, 0700, true) && !is_dir($storage)) $missing[] = 'Yazılabilir storage dizini';
        elseif (!is_writable($storage)) $missing[] = 'Yazılabilir storage dizini';
    }
    if (!$missing) return;
    http_response_code(503);
    $lang = strtolower(substr((string)($_GET['lang'] ?? $_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'tr'), 0, 2));
    $title = $lang === 'tr' ? 'Kurulum için sunucu gereksinimleri eksik' : 'Server requirements are missing';
    $intro = $lang === 'tr' ? 'Plesk/cPanel PHP ayarlarında aşağıdaki gereksinimleri etkinleştirin ve sayfayı yenileyin.' : 'Enable the following requirements in the Plesk/cPanel PHP settings and reload the page.';
    echo '<!doctype html><html lang="'.htmlspecialchars($lang, ENT_QUOTES, 'UTF-8').'" dir="'.(in_array($lang, ['ar','fa'], true) ? 'rtl' : 'ltr').'" ><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.htmlspecialchars($title, ENT_QUOTES, 'UTF-8').' · TofiDesk</title><style>body{font:16px/1.6 system-ui,sans-serif;background:#092b3d;color:#153346;margin:0;padding:28px}.card{max-width:760px;margin:8vh auto;background:#f7faf8;border-radius:18px;padding:34px;box-shadow:0 20px 60px #00141f66}h1{color:#08283a}li{padding:10px;margin:7px 0;background:#fff;border:1px solid #dce8e3;border-radius:8px;color:#a33}code{background:#edf3f0;padding:3px 6px;border-radius:4px}</style><main class="card"><p><strong>TOFIDESK</strong></p><h1>'.htmlspecialchars($title, ENT_QUOTES, 'UTF-8').'</h1><p>'.htmlspecialchars($intro, ENT_QUOTES, 'UTF-8').'</p><ul>'.implode('', array_map(static fn(string $item): string => '<li>✗ '.htmlspecialchars($item, ENT_QUOTES, 'UTF-8').'</li>', $missing)).'</ul><p>PHP 8.2+ · PDO SQLite · SQLite3 · cURL · OpenSSL · mbstring · fileinfo · GD/WebP</p><p><code>/install</code> adresini gereksinimler tamamlandıktan sonra tekrar açın.</p></main></html>';
    exit;
}
$preflightPath = rawurldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
if (PHP_SAPI !== 'cli' || $preflightPath !== '/health') preflight_requirements_page();
// For production point the document root to public/, never to the repository.
$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/');
if (PHP_SAPI === 'cli-server' && str_starts_with($path, '/assets/') && !str_contains($path, '..')) {
    $file = realpath(__DIR__ . $path);
    if ($file && str_starts_with($file, __DIR__ . '/assets/') && is_file($file)) return false;
}
try {
    require dirname(__DIR__) . '/src/bootstrap.php';
} catch (Throwable $exception) {
    http_response_code(503);
    $detail = htmlspecialchars($exception->getMessage(), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TofiDesk kurulum tanılama</title><style>body{font:16px/1.6 system-ui;background:#092b3d;color:#153346;margin:0;padding:28px}.card{max-width:780px;margin:8vh auto;background:#f7faf8;border-radius:18px;padding:34px}h1{color:#08283a}code{display:block;background:#edf3f0;padding:14px;border-radius:8px;white-space:pre-wrap;overflow-wrap:anywhere;color:#7a241b}</style><main class="card"><strong>TOFIDESK</strong><h1>Kurulum tanılaması gerekli</h1><p>PHP sürümü uygun, ancak uygulama başlangıcında veritabanı veya dosya sistemi hatası oluştu. Plesk hata günlüğündeki kayıtla karşılaştırın.</p><code>'.$detail.'</code><p>Kontrol: <b>storage</b> yazma izni, SQLite/PDO SQLite uzantıları ve httpdocs içindeki dosya bütünlüğü.</p></main>';
    exit;
}
// A hosting restore may preserve the migration marker while losing this small
// settings table. Repair it before any public/admin setting lookup.
if (row("SELECT name FROM sqlite_master WHERE type='table' AND name='migrations'")) {
    db()->exec('CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)');
}
try {
    if (rtrim($path, '/') === '/install' && function_exists('handle_install')) { handle_install(); exit; }
    if (!row("SELECT name FROM sqlite_master WHERE type='table' AND name='migrations'")) render_error(503, 'Uygulama kurulumu tamamlanmadı.');
    if (rtrim($path, '/') === '' && !is_file(storage_path('installed.lock')) && (int) row('SELECT count(*) AS n FROM users')['n'] === 0) {
        header('Location: /install', true, 302); exit;
    }
    if (preg_match('/[\x00-\x1f\\\\]/', $path) || str_contains($path, '..')) render_error(400, 'Geçersiz adres.');
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if (!in_array($method, ['GET', 'HEAD', 'POST'], true)) { header('Allow: GET, HEAD, POST'); render_error(405, t('error_method', request_lang())); }
    if ($path === '/health') {
        header('Content-Type: application/json'); header('Cache-Control: no-store');
        echo json_encode([
            'status' => 'ok',
            'product' => 'cms',
            'release' => $tofideskRelease,
            'database' => query('SELECT 1')->fetchColumn() == 1,
            'storage_writable' => is_writable(dirname(__DIR__) . '/storage'),
            'installer_locked' => is_file(storage_path('installed.lock')),
        ], JSON_UNESCAPED_SLASHES); exit;
    }
    if (preg_match('#^/api/gallery/?$#',$path)) {
        $lang=is_string($_GET['lang'] ?? null) ? $_GET['lang'] : 'tr';
        if (!isset(locales()[$lang])) render_error(404, 'Sayfa bulunamadı.');
        public_gallery_json($lang);
    }
    if (preg_match('#^/api/search/?$#', $path)) {
        $lang = is_string($_GET['lang'] ?? null) ? (string)$_GET['lang'] : request_lang();
        $types = is_string($_GET['types'] ?? null) ? array_values(array_filter(explode(',', (string)$_GET['types']), static fn(string $v): bool => preg_match('/^[a-z0-9_-]{1,80}$/', $v))) : [];
        $termIds = is_string($_GET['term_ids'] ?? null) ? array_values(array_filter(array_map('intval', explode(',', (string)$_GET['term_ids'])), static fn(int $v): bool => $v > 0)) : [];
        if (!isset(core_locales()[$lang])) render_error(400, 'Geçersiz arama dili.');
        $result = platform_search_advanced([
            'locale' => $lang,
            'term' => is_string($_GET['q'] ?? null) ? (string)$_GET['q'] : '',
            'types' => $types,
            'term_ids' => $termIds,
            'location_id' => isset($_GET['location_id']) ? (int)$_GET['location_id'] : null,
            'include_descendants' => ($_GET['include_descendants'] ?? '') === '1',
            'latitude' => is_numeric($_GET['lat'] ?? null) ? (float)$_GET['lat'] : null,
            'longitude' => is_numeric($_GET['lon'] ?? null) ? (float)$_GET['lon'] : null,
            'radius_km' => is_numeric($_GET['radius_km'] ?? null) ? min(5000, max(0, (float)$_GET['radius_km'])) : 0,
            'sort' => is_string($_GET['sort'] ?? null) ? (string)$_GET['sort'] : 'updated',
            'limit' => isset($_GET['limit']) ? (int)$_GET['limit'] : 30,
        ]);
        header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: public, max-age=60');
        echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR); exit;
    }
    if (str_starts_with($path, '/api/platform/v1')) platform_api_handle($path);
    if ($path === '/robots.txt') {
        header('Content-Type: text/plain; charset=utf-8');
        if (envv('APP_ENV', 'development') !== 'production') echo "User-agent: *\nDisallow: /\n";
        else echo "User-agent: *\nDisallow: /admin/\nDisallow: /media/\nDisallow: /health\nSitemap: " . base_url('/sitemap.xml') . "\n";
        exit;
    }
    if (envv('APP_ENV', 'development') !== 'production' || str_starts_with($path, '/admin') || str_starts_with($path, '/media')) header('X-Robots-Tag: noindex, nofollow');
    if ($path === '/sitemap.xml') {
        header('Content-Type: application/xml; charset=utf-8');
        $routes = public_routes_for_sitemap(); $groups = [];
        foreach ($routes as $r) $groups[$r['group']][$r['lang']] = $r['path'];
        $xml = fn($v) => htmlspecialchars((string)$v, ENT_QUOTES | ENT_XML1, 'UTF-8');
        echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">';
        foreach ($routes as $r) {
            echo '<url><loc>' . $xml(base_url($r['path'])) . '</loc>';
            foreach ($groups[$r['group']] as $lang => $url) echo '<xhtml:link rel="alternate" hreflang="' . $xml($lang) . '" href="' . $xml(base_url($url)) . '"/>';
            $fallback = $groups[$r['group']]['tr'] ?? reset($groups[$r['group']]);
            echo '<xhtml:link rel="alternate" hreflang="x-default" href="' . $xml(base_url($fallback)) . '"/></url>';
        }
        echo '</urlset>'; exit;
    }
    if (preg_match('#^/media/(\d+)/?$#', $path, $matches)) {
        $media = row('SELECT * FROM media WHERE id=?', [(int)$matches[1]]);
        if (!$media) render_error(404, 'Görsel bulunamadı.');
        $private = $media['purpose'] === 'customer' || (bool)row('SELECT media_id FROM request_media WHERE media_id=?', [$media['id']]);
        if ($private) require_role(['admin','operator']);
        elseif (!row("SELECT id FROM translations WHERE cover_media_id=? AND status='published' AND (scheduled_at IS NULL OR scheduled_at='' OR scheduled_at<=datetime('now'))", [$media['id']]) && !row("SELECT id FROM gallery_items WHERE media_id=? AND status='published'",[$media['id']])) require_role(['admin','editor']);
        $variant = $_GET['variant'] ?? 'webp';
        if (!is_string($variant) || !in_array($variant, ['original', 'webp', 'avif'], true)) render_error(400, 'Geçersiz görsel biçimi.');
        try { $file = media_path($media, $variant); } catch (RuntimeException $error) { render_error(404, 'Görsel bulunamadı.'); }
        if (!is_file($file)) render_error(404, 'Görsel bulunamadı.');
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($file);
        if (!in_array($mime, ['image/jpeg','image/png','image/webp','image/avif'], true)) render_error(404, 'Görsel bulunamadı.');
        header('Content-Type: ' . $mime); header('Cache-Control: ' . ($private ? 'no-store' : 'private, max-age=3600')); header('Content-Length: ' . filesize($file)); readfile($file); exit;
    }
    header('Content-Type: text/html; charset=utf-8');
    if (str_starts_with($path, '/admin')) { header('Cache-Control: no-store'); handle_admin(rtrim($path, '/') ?: '/admin'); }
    else handle_public($path);
} catch (Throwable $error) {
    error_log(get_class($error) . ': ' . $error->getMessage());
    render_error(500, t('error_server', request_lang()));
}
