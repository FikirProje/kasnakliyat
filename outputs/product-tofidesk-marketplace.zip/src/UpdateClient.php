<?php
declare(strict_types=1);
function update_installation_id(): string { $path=storage_path('installation.id'); $id=is_file($path)?trim((string)file_get_contents($path)):''; if(!preg_match('/^[a-f0-9]{32}$/',$id)){ $id=bin2hex(random_bytes(16)); @file_put_contents($path,$id,LOCK_EX); @chmod($path,0600); } return $id; }
function update_current_version(): string
{
    try {
        $stored = (string) (setting('app_version', '') ?? '');
        if (preg_match('/^\d+(?:\.\d+){1,3}(?:[-+][A-Za-z0-9.-]+)?$/', $stored)) return $stored;
    } catch (Throwable) {
        // The installer may call the update client before the settings table exists.
    }
    $fallback = (string) envv('APP_VERSION', '1.0.0');
    return preg_match('/^\d+(?:\.\d+){1,3}(?:[-+][A-Za-z0-9.-]+)?$/', $fallback) ? $fallback : '1.0.0';
}
function update_preflight(): array { return ['PHP '.PHP_VERSION=>version_compare(PHP_VERSION,'8.2.0','>='),'PDO SQLite'=>extension_loaded('pdo_sqlite'),'ZIP'=>class_exists('ZipArchive'),'cURL'=>function_exists('curl_init'),'OpenSSL'=>extension_loaded('openssl'),'storage yazılabilir'=>is_dir(storage_path())&&is_writable(storage_path()),'backup dizini yazılabilir'=>is_dir(storage_path('backups'))&&is_writable(storage_path('backups'))]; }
function update_verify_signature(array $release): bool
{
    $public = trim((string) envv('RELEASE_SIGNING_PUBLIC_KEY', ''));
    $signature = (string) ($release['signature'] ?? '');
    $manifest = $release['manifest'] ?? null;
    if ($public === '' || !is_array($manifest) || !str_starts_with($signature, 'RSA-SHA256.')) return false;
    $publicKey = openssl_pkey_get_public($public);
    if ($publicKey === false) return false;
    $raw = base64_decode(substr($signature, 11), true);
    if (!is_string($raw) || $raw === '') return false;
    $canonical = json_encode($manifest, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    return openssl_verify($canonical, $raw, $publicKey, OPENSSL_ALGO_SHA256) === 1;
}
function update_check(bool $force=false): array {
    $cachePath=storage_path('update-check.json'); $cached=is_file($cachePath)?json_decode((string)file_get_contents($cachePath),true):null; $now=time();
    if(!$force && is_array($cached) && (int)($cached['checked_at_unix']??0)>$now-900)return $cached;
    $key=trim((string)setting('license_key','')); $server=license_server_url();
    if($key===''||!filter_var($server,FILTER_VALIDATE_URL))return ['configured'=>false,'message'=>'Lisans anahtarı ve lisans merkezi ayarlanmalı.'];
    $payload=['license_key'=>$key,'domain'=>license_domain(),'product'=>envv('PRODUCT_SLUG','tofidesk-cms'),'installation_id'=>update_installation_id(),'installed_version'=>update_current_version(),'migration_version'=>envv('MIGRATION_VERSION','1'),'php_version'=>PHP_VERSION];
    $ch=curl_init($server.'/updates.php'); curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($payload),CURLOPT_HTTPHEADER=>['Content-Type: application/json','Accept: application/json'],CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>8,CURLOPT_CONNECTTIMEOUT=>4,CURLOPT_SSL_VERIFYPEER=>true]); $raw=curl_exec($ch); $error=curl_error($ch); $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); curl_close($ch); $result=is_string($raw)?json_decode($raw,true):null;
    if(!is_array($result)||$code<200||$code>=300){if(is_array($cached)&&(int)($cached['checked_at_unix']??0)>$now-604800){$cached['offline']=true;$cached['message']='Lisans merkezi geçici olarak erişilemiyor; son güvenli sonuç gösteriliyor.';return $cached;}return ['configured'=>true,'active'=>false,'offline'=>true,'message'=>'Güncelleme kontrolü yapılamadı.'.($error?' Sunucu bağlantısını kontrol edin.':'')];}
    $result['configured']=true;$result['checked_at_unix']=$now;$result['checked_at']=date('c');@file_put_contents($cachePath,json_encode($result),LOCK_EX);@chmod($cachePath,0600);return $result;
}
function update_download(array $release): string
{
    $fresh=update_check(true); if(is_array($fresh['update']??null)&&($fresh['update']['version']??'')===($release['version']??''))$release=$fresh['update'];
    $key=trim((string)setting('license_key','')); $server=license_server_url(); $version=(string)($release['version']??'');
    if($key===''||$version===''||!filter_var($server,FILTER_VALIDATE_URL)) throw new RuntimeException('Güncelleme indirme ayarları eksik.');
    $path=storage_path('update-'.$version.'.zip'); $ch=curl_init($server.'/updates.php'); $fp=fopen($path,'wb'); if(!$fp)throw new RuntimeException('Güncelleme geçici dosyası oluşturulamadı.');
    $payload=['action'=>'download','license_key'=>$key,'domain'=>license_domain(),'product'=>envv('PRODUCT_SLUG','tofidesk-cms'),'installation_id'=>update_installation_id(),'installed_version'=>update_current_version(),'version'=>$version];
    curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($payload),CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_FILE=>$fp,CURLOPT_TIMEOUT=>60,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_SSL_VERIFYPEER=>true]); $ok=curl_exec($ch); $code=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); $error=curl_error($ch); curl_close($ch); fclose($fp);
    if(!$ok||$code<200||$code>=300){@unlink($path);throw new RuntimeException('Güncelleme paketi indirilemedi.'.($error?' Bağlantıyı kontrol edin.':''));}
    $expected=strtolower((string)($release['sha256']??'')); if(!update_verify_signature($release)||!preg_match('/^[a-f0-9]{64}$/',$expected)||!hash_equals($expected,strtolower(hash_file('sha256',$path)))){@unlink($path);throw new RuntimeException('Güncelleme paketi imza veya SHA-256 doğrulamasından geçmedi.');}
    chmod($path,0600); return $path;
}
function update_archive_copy(string $source,string $destination): void
{
    if(!is_dir($destination)&&!mkdir($destination,0700,true))throw new RuntimeException('Güncelleme yedek dizini oluşturulamadı.');
    $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::SELF_FIRST);
    foreach($it as $item){$rel=str_replace('\\','/',substr($item->getPathname(),strlen($source)+1));if($rel===''||str_starts_with($rel,'storage/')||$rel==='.env')continue;$target=$destination.'/'.$rel;if($item->isDir()){if(!is_dir($target))mkdir($target,0700,true);}else{if(!is_dir(dirname($target)))mkdir(dirname($target),0700,true);copy($item->getPathname(),$target);}}
}
function update_restore_copy(string $source,string $destination): void
{
    // A rollback must remove files introduced by the failed release as well
    // as restoring files that existed before it. Runtime data and .env stay
    // outside the application release boundary.
    if (!is_dir($source)) throw new RuntimeException('Geri alma kaynağı bulunamadı.');
    if (!is_dir($destination) && !mkdir($destination,0700,true)) throw new RuntimeException('Geri alma hedefi oluşturulamadı.');
    $sourceFiles=[];
    $sourceIterator=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($source,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::SELF_FIRST);
    foreach($sourceIterator as $item){$rel=str_replace('\\','/',substr($item->getPathname(),strlen($source)+1));if($rel===''||str_starts_with($rel,'storage/')||$rel==='.env')continue;$sourceFiles[$rel]=true;}
    $destinationIterator=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($destination,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
    foreach($destinationIterator as $item){$rel=str_replace('\\','/',substr($item->getPathname(),strlen($destination)+1));if($rel===''||str_starts_with($rel,'storage/')||$rel==='.env')continue;if(!isset($sourceFiles[$rel])){if($item->isDir())@rmdir($item->getPathname());else@unlink($item->getPathname());}}
    update_archive_copy($source,$destination);
}
function update_apply(string $version,string $minPhp='',int $migrationRequired=0): string
{
    if($minPhp!==''&&version_compare(PHP_VERSION,$minPhp,'<'))throw new RuntimeException('Bu güncelleme PHP '.$minPhp.' veya üzerini gerektiriyor.');
    if ($migrationRequired < 0) throw new RuntimeException('Güncelleme migration sürümü geçersiz.');
    $zipPath=storage_path('update-'.$version.'.zip'); if(!is_file($zipPath))throw new RuntimeException('Önce güncelleme paketini indirin.');
    $staging=storage_path('update-staging-'.$version); $rollback=storage_path('update-rollback-'.$version); if(is_dir($staging))integration_remove_tree($staging);if(is_dir($rollback))throw new RuntimeException('Bu sürüm için geri alma kaydı zaten mevcut.');
    $zip=new ZipArchive();if($zip->open($zipPath)!==true)throw new RuntimeException('Güncelleme ZIP dosyası açılamadı.');
    for($i=0;$i<$zip->numFiles;$i++){ $name=str_replace('\\','/',$zip->getNameIndex($i)); if($name===''||str_starts_with($name,'/')||preg_match('#(^|/)\.\.?(/|$)#',$name)){$zip->close();throw new RuntimeException('Güncelleme paketi geçersiz yol içeriyor.');} }
    if(!$zip->extractTo($staging)){$zip->close();throw new RuntimeException('Güncelleme geçici alana açılamadı.');}$zip->close();
    $root=$staging; if(is_dir($staging.'/httpdocs'))$root=$staging.'/httpdocs'; elseif(is_dir($staging.'/app'))$root=$staging.'/app';
    if(!is_file($root.'/src/bootstrap.php')&&!is_file($root.'/index.php')){integration_remove_tree($staging);throw new RuntimeException('Paket uygulama kökü doğrulanamadı.');}
    $backup=create_backup(); update_archive_copy(ROOT,$rollback); file_put_contents(storage_path('maintenance.flag'),gmdate('c'),LOCK_EX);
    try {
        update_archive_copy($root,ROOT);
        migrate();
        $appliedMigration = (int) (row('SELECT COALESCE(MAX(version),0) AS version FROM migrations')['version'] ?? 0);
        if ($migrationRequired > 0 && $appliedMigration < $migrationRequired) {
            throw new RuntimeException('Güncelleme migrationları hedef sürüme ulaşmadı.');
        }
        save_setting('app_version',$version);
        audit('update.applied',$version);
        @unlink($zipPath);
        integration_remove_tree($staging);
        @unlink(storage_path('maintenance.flag'));
        return $backup;
    }
    catch(Throwable $e){ if(is_dir($rollback))update_restore_copy($rollback,ROOT);@unlink(storage_path('maintenance.flag'));throw $e; }
}
